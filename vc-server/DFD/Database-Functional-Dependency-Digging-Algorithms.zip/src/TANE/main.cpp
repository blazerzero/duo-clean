#include "TANE.hpp"


int main(int argc, const char * argv[])
{
    double start, stop, durationTime;
    start = clock();
    TANE("input file path");
    stop = clock();
    durationTime = ((double)(stop - start)) / CLOCKS_PER_SEC;
    cout << durationTime << "s" << endl;
    return 0;
}
